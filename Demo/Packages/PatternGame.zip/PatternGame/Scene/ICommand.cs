using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Package.ExamplePackage
{
    public interface ICommand
    {
        void Execute();



    }
}